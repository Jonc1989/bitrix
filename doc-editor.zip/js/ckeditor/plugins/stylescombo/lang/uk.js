/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'uk', {
	label: 'Стиль',
	panelTitle: 'Стилі форматування',
	panelTitle1: 'Блочні стилі',
	panelTitle2: 'Рядкові стилі',
	panelTitle3: 'Об\'єктні стилі'
} );
