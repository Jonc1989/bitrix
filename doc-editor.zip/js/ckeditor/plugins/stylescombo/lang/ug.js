/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'ug', {
	label: 'ئۇسلۇب',
	panelTitle: 'ئۇسلۇب',
	panelTitle1: 'بۆلەك دەرىجىسىدىكى ئېلېمېنت ئۇسلۇبى',
	panelTitle2: 'ئىچكى باغلانما ئېلېمېنت ئۇسلۇبى',
	panelTitle3: 'نەڭ (Object) ئېلېمېنت ئۇسلۇبى'
} );
