/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'fr-ca', {
	label: 'Styles',
	panelTitle: 'Styles de formattage',
	panelTitle1: 'Styles de block',
	panelTitle2: 'Styles en ligne',
	panelTitle3: 'Styles d\'objet'
} );
