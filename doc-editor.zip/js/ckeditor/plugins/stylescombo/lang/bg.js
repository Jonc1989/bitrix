/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'bg', {
	label: 'Стилове',
	panelTitle: 'Стилове за форматиране',
	panelTitle1: 'Блокови стилове',
	panelTitle2: 'Вътрешни стилове',
	panelTitle3: 'Обектни стилове'
} );
