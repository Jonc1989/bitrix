/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'stylescombo', 'ja', {
	label: 'スタイル',
	panelTitle: 'スタイル',
	panelTitle1: 'ブロックスタイル',
	panelTitle2: 'インラインスタイル',
	panelTitle3: 'オブジェクトスタイル'
} );
