(function () {
    console.log('Here i am bitch !');
})();